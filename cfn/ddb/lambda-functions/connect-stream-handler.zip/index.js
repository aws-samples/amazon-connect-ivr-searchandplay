'use strict';
const targetTable = 'connectRecordings';
const AWS = require("aws-sdk");
const DDB = new AWS.DynamoDB({params: {TableName: targetTable}});
var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
	//logger.info("Testing Logger");
	console.log('Event received');
	console.log('Destination table: ', targetTable);
  event.Records.forEach((record) => {
    console.log('Stream record: ', JSON.stringify(record, null, 2));

    if (record.eventName !== 'INSERT') {
    	console.log('Not an INSERT operation. Skipping record');
    	//continue;
    }

  	//const insertedRecord = record;
  	switch(true){

  		// Initial session recording
  		case (record.eventName == "session" && record.eventType == "start"):
  			console.log("Event Type: New session");
  			//console.log('Stream record: ', JSON.stringify(record, null, 2));
	    	var newRecord = {
	    	   Item: {
						sessionId: {S: record.sessionId},
						startDateTime: {S: record.eventTime},
						callflowName: {S: record.callflowName},
						connectId: {S: record.connectId},
						recordingPath: {S: record.recordingPath},
						cli: {S: record.cli},
						did: {S: record.did},
						ctiIn: {S: record.ctiIn},
						ctiId: {S: record.ctiId},
						dummykey: {S: "123"}
					}
	    	};
  			console.log("Saving record ", JSON.stringify(newRecord, null, 2));
  			// Call DynamoDB to add the item to the table
			DDB.putItem(newRecord, function(err, data) {
			  if (err) {
			    console.log("Error", err);
			  } else {
			    console.log("Success", data);
			  }
			});
			//	DDB.putItem(newRecord);
	    	break;

	    // Auth complete. have account details
  		case (record.eventName == "auth" && record.eventType == "end"):
  			console.log("Event Type: AuthEnd");
  			console.log("sessionId : ", record.sessionId);

  			var params = {
			    TableName: targetTable,
			    KeyConditionExpression: "sessionId = :id",
    			ExpressionAttributeValues: {
    				':id': record.sessionId
    			}
			};

		 docClient.query(params, function(err, data) {
			    if (err)
			        console.log(JSON.stringify(err, null, 2));
			    else {
			        console.log(JSON.stringify(data, null, 2));
			        record.startDateTime = data.Items[0].startDateTime;
			        console.log("myStartDateTime : ", data.Items[0]);
			        console.log("myStartDateTime : ", data.Items[0].startDateTime);

			        var updateParams = {
				    UpdateExpression: "SET accountNumber = :n, accountJurisdiction = :j",
					ExpressionAttributeValues: {
					 ":n": { S: record.accountNumber },
					 ":j": { S: record.accountJurisdiction }
					},
					Key: { sessionId : { S: record.sessionId },
					 startDateTime : { S: record.startDateTime}},
					ReturnValues: "NONE",
					TableName: targetTable
				    };

					console.log("Updating record ", JSON.stringify(updateParams, null, 2));
			    	//DDB.updateItem(params);
			    	DDB.updateItem(updateParams, function(err, data) {
					  if (err) {
					    console.log("Error", err);
					  } else {
					    console.log("Success", data);
					  }
					});
			    	}
				});
	    	break;

	    // End of CTI Flow. have purecloudid
  		case (record.eventName == "cti" && record.eventType == "end"):
  			console.log("Event Type: CTI Flow");
  			console.log("sessionId : ", record.sessionId);

  			var params = {
			    TableName: targetTable,
			    KeyConditionExpression: "sessionId = :id",
    			ExpressionAttributeValues: {
    				':id': record.sessionId
    			}
			};

		 docClient.query(params, function(err, data) {
			    if (err)
			        console.log(JSON.stringify(err, null, 2));
			    else {
			        console.log(JSON.stringify(data, null, 2));
			        record.startDateTime = data.Items[0].startDateTime;
			        console.log("myStartDateTime : ", data.Items[0]);
			        console.log("myStartDateTime : ", data.Items[0].startDateTime);

			        var updateParams = {
				    UpdateExpression: "SET purecloudId = :p",
					ExpressionAttributeValues: {
					 ":p": { S: record.purecloudId}
					},
					Key: { sessionId : { S: record.sessionId },
					 startDateTime : { S: record.startDateTime}},
					ReturnValues: "NONE",
					TableName: targetTable
				    };

					console.log("Updating record ", JSON.stringify(updateParams, null, 2));
			    	//DDB.updateItem(params);
			    	DDB.updateItem(updateParams, function(err, data) {
					  if (err) {
					    console.log("Error", err);
					  } else {
					    console.log("Success", data);
					  }
					});
			    	}
				});
	    	break;

	    // Session end. Have endReason
  		case (record.eventName == "conversationRequest" && record.eventType == "end"):
  			console.log("Event Type: Session End");
  			console.log("sessionId : ", record.sessionId);

  			var params = {
			    TableName: targetTable,
			    KeyConditionExpression: "sessionId = :id",
    			ExpressionAttributeValues: {
    				':id': record.sessionId
    			}
			};

		 docClient.query(params, function(err, data) {
			    if (err)
			        console.log(JSON.stringify(err, null, 2));
			    else {
			        console.log(JSON.stringify(data, null, 2));
			        record.startDateTime = data.Items[0].startDateTime;
			        console.log("myStartDateTime : ", data.Items[0]);
			        console.log("myStartDateTime : ", data.Items[0].startDateTime);

			        var updateParams = {
				    UpdateExpression: "SET endReason = :r",
					ExpressionAttributeValues: {
					 ":r": { S: record.endReason}
					},
					Key: { sessionId : { S: record.sessionId },
					 startDateTime : { S: record.startDateTime}},
					ReturnValues: "NONE",
					TableName: targetTable
				    };

					console.log("Updating record ", JSON.stringify(updateParams, null, 2));
			    	//DDB.updateItem(params);
			    	DDB.updateItem(updateParams, function(err, data) {
					  if (err) {
					    console.log("Error", err);
					  } else {
					    console.log("Success", data);
					  }
					});
			    	}
				});
	    	break;


	    default:
	    	console.log('Inserted record didnt match an logic conditions. Skipping record');
	    	//continue;
	  } // switch
  });
  callback(null, `Successfully processed ${event.Records.length} records.`);
};
